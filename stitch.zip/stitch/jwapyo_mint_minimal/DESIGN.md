# Design System: High-End Editorial Strategy for 좌표.to

## 1. Overview & Creative North Star
The Creative North Star for this system is **"The Digital Curator."** 

Unlike standard utility tools that feel like cold spreadsheets, this system treats URL management as a high-end editorial experience. By leveraging the geometric beauty of the Korean script (Hangul), the design moves away from rigid, boxy templates toward a layout defined by **intentional asymmetry** and **tonal depth**. We break the "generic SaaS" mold by using expansive white space as a structural element, overlapping components to create a sense of physical layering, and utilizing high-contrast typography scales that command attention. The result is a service that feels premium, authoritative, and bespoke.

---

## 2. Colors
Our palette is rooted in a sophisticated "Deep Mint & Charcoal" harmony. This is not just about color—it is about the intentionality of depth.

*   **Primary (`#006565` / `#008080`):** Used as a surgical strike for brand identity and critical actions.
*   **Secondary/Neutral (`#5f5e5e` / `#1a1c1c`):** The "Dark Charcoal" anchor. It provides the editorial weight necessary for buttons and navigation.
*   **Surface Strategy:** We use a cascading series of white and off-white (`surface` to `surface-container-highest`) to build depth.

### The "No-Line" Rule
Standard 1px borders are prohibited for sectioning. Structural boundaries must be defined solely through background color shifts. For example, a `surface-container-low` (#f3f3f3) section should sit directly on a `surface` (#f9f9f9) background. Use white space and tonal transitions to guide the eye, not lines.

### The "Glass & Gradient" Rule
To elevate the experience, floating elements (like the URL preview card) should utilize a **Glassmorphism** effect:
*   **Background:** `surface-container-lowest` at 80% opacity.
*   **Effect:** `backdrop-blur` (12px to 20px).
*   **CTA Soul:** Primary buttons should use a subtle linear gradient from `primary` (#006565) to `primary_container` (#008080) at a 135-degree angle to add a "jeweled" professional finish.

---

## 3. Typography
The typography system is designed to celebrate the vertical and horizontal strokes of Hangul. We pair the geometric authority of **Manrope** (for English/Numerical displays) with the humanist clarity of **Plus Jakarta Sans** (optimized for Korean readability).

*   **Display (Manrope):** Massive, bold weights for the main value proposition. These should feel like a magazine header.
*   **Headline & Title (Manrope/Plus Jakarta Sans):** Used to create a rhythmic hierarchy. Bold weights are the default for Korean text to ensure high legibility against the vast white space.
*   **Body & Labels (Plus Jakarta Sans):** Generous line heights (1.6 - 1.8) are mandatory. Hangul requires more vertical breathing room than Latin characters to avoid visual "clogging."

---

## 4. Elevation & Depth
We eschew traditional drop shadows for **Tonal Layering**.

*   **The Layering Principle:** Treat the UI as stacked sheets of fine paper. A card (using `surface-container-lowest`) sits on a section (using `surface-container-low`). The 1-step shift in the container tier provides a natural "lift."
*   **Ambient Shadows:** When an element must float (e.g., a modal or a primary input), use a "Whisper Shadow":
    *   **Blur:** 32px to 64px.
    *   **Opacity:** 4% - 6%.
    *   **Color:** Use a tinted version of `on-surface` (e.g., a dark teal-grey) rather than pure black to mimic natural light.
*   **The "Ghost Border" Fallback:** If a container needs a border for accessibility, use the `outline_variant` token at **15% opacity**. A solid, 100% opaque border is a failure of the design system.

---

## 5. Components

### Input Fields (The "Focal Point")
The URL input is the heart of the product. 
*   **Style:** Minimalist container using `surface_container_lowest`.
*   **State:** On focus, the `outline` should not be a harsh blue, but a soft transition to `primary` with a subtle glow (Whisper Shadow).
*   **Radius:** Use `xl` (0.75rem) for a modern, approachable feel.

### Buttons
*   **Primary (Charcoal):** Use `on_background` (#1a1c1c) for the container and `surface` for text. This "Dark Mode" button on a "Light Mode" canvas provides maximum contrast and an editorial aesthetic.
*   **Tertiary/Ghost:** Use `on_surface_variant` with no container. Hover states should trigger a `surface-container-high` background shift.

### Cards & Lists
*   **Rule:** Forbid the use of divider lines between list items. 
*   **Execution:** Use the Spacing Scale (minimum 24px) or a subtle shift from `surface` to `surface-container-lowest` to distinguish between entries.
*   **Grid:** Use an asymmetric grid. For example, three info-cards at the bottom should have varying internal alignment to feel like a curated gallery rather than a generic table.

### Chips (URL Tags)
*   **Style:** Use `secondary_container` with `on_secondary_container` text. Keep the `rounded-full` shape to contrast with the `xl` radius of cards.

---

## 6. Do's and Don'ts

### Do:
*   **Do** emphasize the "좌표.to/..." text in a larger font size and bolder weight than the surrounding helper text.
*   **Do** use asymmetrical margins (e.g., a larger left margin for the hero text) to create an editorial layout.
*   **Do** ensure all Korean text uses a minimum of `medium` weight for headlines to maintain the "Modern Korean" aesthetic.

### Don't:
*   **Don't** use 100% black (#000000). Use the `on_background` charcoal (#1a1c1c) for all "black" elements to keep the palette soft and high-end.
*   **Don't** use "Card-in-Card" patterns with multiple borders. Use background tonal shifts to nest information.
*   **Don't** crowd the interface. If a screen feels "busy," increase the spacing scale rather than adding icons or lines.